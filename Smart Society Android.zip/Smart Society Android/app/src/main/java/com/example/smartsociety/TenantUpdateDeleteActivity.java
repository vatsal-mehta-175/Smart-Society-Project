package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class TenantUpdateDeleteActivity extends AppCompatActivity {
  EditText fname,lname,phone,email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_update_delete);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

      fname=(EditText) findViewById(R.id.t_fname);
      lname=(EditText) findViewById(R.id.t_lname);
      phone=(EditText) findViewById(R.id.t_contact);
      email=(EditText) findViewById(R.id.t_email);


      //change with data from backend
      fname.setText("Deeksha");
      lname.setText("Jain");
      phone.setText("1111111111");
      email.setText("abc@gmail.com");
    }
  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    public void updateTenant(View view) {
        Toast.makeText(this, "Update Tenant Invoked", Toast.LENGTH_SHORT).show();
    }

    public void deleteTenant(View view) {
        Toast.makeText(this, "Delete Tenant Invoked", Toast.LENGTH_SHORT).show();
    }
}
