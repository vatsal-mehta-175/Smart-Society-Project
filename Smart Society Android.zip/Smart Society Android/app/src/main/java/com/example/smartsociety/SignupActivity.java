package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.app.VoiceInteractor;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

//    EditText apartment_no, f_name,l_name, contact , pass,confirmpass;
//    Spinner block;
//    Button btnSignup;

    //final String url_Signup="52.66.187.237:3000/adminlogin"; //api url  provided by vatsal
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Spinner spinner =findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.block_numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

//        block=(Spinner) findViewById(R.id.spinner1);
//        apartment_no=(EditText) findViewById(R.id.apartment);
//        f_name=(EditText) findViewById(R.id.first);
//        l_name=(EditText) findViewById(R.id.last);
//        contact=(EditText) findViewById(R.id.contactno);
//        pass=(EditText) findViewById(R.id.password);
//        confirmpass=(EditText) findViewById(R.id.confirmpassword);
//
//        if(pass!=confirmpass)
//            Toast.makeText(this, "Password should match confirm password", Toast.LENGTH_SHORT).show();
//
//        btnSignup=(Button) findViewById(R.id.registerbtn);






    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        String block=parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(),block,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent)
    {

    }

    public void btn_LoginForm(View view)
    {
        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
    }
}