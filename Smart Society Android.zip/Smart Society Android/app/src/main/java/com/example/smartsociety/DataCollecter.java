package com.example.smartsociety;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DataCollecter extends AppCompatActivity {
    ImageView image;
    Button btnclick;
    Button btnsave;
    Button btnfile;
    Spinner dropdown;
    EditText name;
    EditText desc;
    Intent cameraIntent;
    String[] per={Manifest.permission.CAMERA,Manifest.permission.READ_EXTERNAL_STORAGE};
    byte[] Imagedata;
    Context context = this;
    public static final int cameraper=1;
    public static final int pictake=2;
    public static final int fileper=3;
    public static final int filetake=4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_collecter);
        image=findViewById(R.id.image);
        btnclick=findViewById(R.id.button);
        btnfile=findViewById(R.id.btn_picker);
        btnsave=findViewById(R.id.btn_save);
        name=findViewById(R.id.txt_name);
        dropdown=findViewById(R.id.dd_Status);
        desc=findViewById(R.id.txt_desc);
        String[] items = new String[]{"Available", "UnAvailable"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);
        btnclick.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(checkSelfPermission(Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){

                    requestPermissions(per,cameraper);
                }else{
                    TakePic();
                }
            }
        });
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((Imagedata == null) || name.getText().toString().matches("") ||desc.getText().toString().matches("")){
                    Toast.makeText(context,"Please Fill all the values",Toast.LENGTH_SHORT).show();
                }else{
                    POSTDATA();
                }
            }
        });
        btnfile.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(per,fileper);
                }else{TakeFile();}
            }
        });
    }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case cameraper:
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){TakePic();}
                else{
                    Toast.makeText(this,"Need Camera Permission",Toast.LENGTH_SHORT).show();
                }
                break;
            case fileper:
                if(grantResults[1]==PackageManager.PERMISSION_GRANTED){TakeFile();}
                else{
                    Toast.makeText(this,"Need Camera Permission",Toast.LENGTH_SHORT).show();
                }
                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK) {
            switch (requestCode) {
                case pictake:
                    Bitmap TakenIamge = (Bitmap) data.getExtras().get("data");
                    image.setImageBitmap(TakenIamge);
                    setImagedata(TakenIamge);
                    break;
                case filetake:
                    final Uri SelectedImageUri = data.getData();
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), SelectedImageUri);
                        setImagedata(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    if (null != SelectedImageUri) {
                        image.post(new Runnable() {
                            @Override
                            public void run() {
                                image.setImageURI(SelectedImageUri);

                            }
                        });

                    }
                    break;
            }
        }
    }

    private void TakePic(){
        cameraIntent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent,pictake);
    }
    private  void TakeFile(){

        cameraIntent=new Intent();
        cameraIntent.setType("image/*");
        cameraIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(cameraIntent,filetake);

    }
    private void setImagedata(Bitmap TakenIamge){
        if(TakenIamge!=null) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            TakenIamge.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            Imagedata = stream.toByteArray();
        }
        else{Toast.makeText(this,"api call",Toast.LENGTH_SHORT).show();}
    }
    void POSTDATA(){
        String URL="http://52.66.187.237:3000/adminAmenities";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

               if (response.charAt(1) == '0') {
                  Toast.makeText(DataCollecter.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(DataCollecter.this, "Success", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Amenities_MainActivity.class);
                    startActivity(intent);
                    finish();
               }

            /*JSONArray jsonArray = new JSONArray(response);
            if (jsonArray.length() == 0) {
              Toast.makeText(LoginActivity.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
            } else {
              Log.e("HELLO", response);
              String userPhoneNumber = "", userName = "", userTypeId = "";
              JSONObject jsonObject1 = jsonArray.getJSONObject(0);
              userPhoneNumber = jsonObject1.getString("userPhoneNumber");
              userName = jsonObject1.getString("userName");
              userTypeId = jsonObject1.getString("userTypeId");
              String type = jsonObject1.getString("name");
              editor.putString("userPhoneNumber", userPhoneNumber);
              editor.putString("userName", userName);
              editor.putString("userTypeId", userTypeId);
              editor.putString("type", type);
              Log.e("LOGIN",type);
              editor.commit();

              Intent intent;
              if (type.equals("secretary")) {
                intent = new Intent(LoginActivity.this, SecretaryActivity.class);
              } else if (type.equals("user")) {
                intent = new Intent(LoginActivity.this, UserActivity.class);
              } else {
                intent = new Intent(LoginActivity.this, LoginActivity.class);
              }
              intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
              intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
              startActivity(intent);
              finish();
            }*/

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(DataCollecter.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();
                String image=  Base64.encodeToString(Imagedata, Base64.DEFAULT);
                params.put("am_name",name.getText().toString());
                params.put("am_description",desc.getText().toString());
                if(dropdown.getSelectedItem().toString().matches("Available")){params.put("am_status","1");}
                else{params.put("am_status","0");}
                params.put("uploaded_image",image);

                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}
