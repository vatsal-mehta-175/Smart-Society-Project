package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class StaffUpdateActivity extends AppCompatActivity {

  EditText fname, lname, phone;
  Spinner status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_update);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        fname=(EditText) findViewById(R.id.staff_first);
        lname=(EditText) findViewById(R.id.staff_last);
        phone=(EditText) findViewById(R.id.staff_contact);
        status=(Spinner) findViewById(R.id.staff_status);

      //change with data from backend
        fname.setText("Deeksha");
        lname.setText("Jain");
        phone.setText("1111111111");
        status.setSelection(1);//here 1 is position


    }
  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    public void updateStaff(View view) {

      if (fname.getText().toString().matches("") || lname.getText().toString().matches("") || phone.getText().toString().matches("")) {
        Toast.makeText(this, "Please Fill all the values", Toast.LENGTH_SHORT).show();
      } else {
        if (phone.getText().toString().length() != 10) {
          Toast.makeText(this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
        } else {

          //code for update





        }
        }
        Toast.makeText(this,"Update Staff Invoked", Toast.LENGTH_SHORT).show();
    }
    //three dots code ends
}
