package com.example.smartsociety;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class complaint_DataCollecter extends AppCompatActivity {

    ImageView image;
    Button btnclick;
    Button btnsave;
    Button btnfile;
    EditText name;
    EditText desc;
    Intent cameraIntent;
    String[] per={Manifest.permission.CAMERA,Manifest.permission.READ_EXTERNAL_STORAGE};
    byte[] Imagedata;
    Context context = this;
    public static final int cameraper=1;
    public static final int pictake=2;
    public static final int fileper=3;
    public static final int filetake=4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint__data_collecter);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        image=findViewById(R.id.com_image);
        btnclick=findViewById(R.id.com_button);
        btnfile=findViewById(R.id.com_btn_picker);
        btnsave=findViewById(R.id.com_btn_save);
        name=findViewById(R.id.com_txt_name);
        desc=findViewById(R.id.com_txt_desc);
        btnclick.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(checkSelfPermission(Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){

                    requestPermissions(per,cameraper);
                }else{
                    TakePic();
                }
            }
        });
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if( name.getText().toString().matches("") ||desc.getText().toString().matches("")){
                    Toast.makeText(context,"Please Fill all the values",Toast.LENGTH_SHORT).show();
                }else{
                    POSTDATA();
                }
            }
        });
        btnfile.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(per,fileper);
                }else{TakeFile();}
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case cameraper:
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){TakePic();}
                else{
                    Toast.makeText(this,"Need Camera Permission",Toast.LENGTH_SHORT).show();
                }
                break;
            case fileper:
                if(grantResults[1]==PackageManager.PERMISSION_GRANTED){TakeFile();}
                else{
                    Toast.makeText(this,"Need Camera Permission",Toast.LENGTH_SHORT).show();
                }
                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK) {
            switch (requestCode) {
                case pictake:
                    Bitmap TakenIamge = (Bitmap) data.getExtras().get("data");
                    image.setImageBitmap(TakenIamge);
                    setImagedata(TakenIamge);
                    break;
                case filetake:
                    final Uri SelectedImageUri = data.getData();
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), SelectedImageUri);
                        setImagedata(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    if (null != SelectedImageUri) {
                        image.post(new Runnable() {
                            @Override
                            public void run() {
                                image.setImageURI(SelectedImageUri);

                            }
                        });

                    }
                    break;
            }
        }
    }

    private void TakePic(){
        cameraIntent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent,pictake);
    }
    private  void TakeFile(){

        cameraIntent=new Intent();
        cameraIntent.setType("image/*");
        cameraIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(cameraIntent,filetake);

    }
    private void setImagedata(Bitmap TakenIamge){
        if(TakenIamge!=null) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            TakenIamge.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            Imagedata = stream.toByteArray();
        }
        else{Toast.makeText(this,"api call",Toast.LENGTH_SHORT).show();}
    }
    void POSTDATA(){
        String URL="http://52.66.187.237:3000/residence_complaint";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(complaint_DataCollecter.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(complaint_DataCollecter.this, "Success", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), complaint_DataCollecter.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(complaint_DataCollecter.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();
                if(Imagedata!=null){
                    String image=  Base64.encodeToString(Imagedata, Base64.DEFAULT);
                    params.put("uploaded_image",image);
                }
                params.put("c_title",name.getText().toString());
                params.put("c_description",desc.getText().toString());
                params.put("r_house", "A101");
                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}
