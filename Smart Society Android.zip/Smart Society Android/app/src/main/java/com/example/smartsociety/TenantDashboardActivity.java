package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class TenantDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_dashboard);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    public void NoticeModule(View view) {
      startActivity(new Intent(getApplicationContext(), Notice_MainActivity.class));
        //Toast.makeText(this,"Opening Notice Module", Toast.LENGTH_SHORT).show();
    }

    public void DirectoryModule(View view) {
        Toast.makeText(this,"Opening Directory Module", Toast.LENGTH_SHORT).show();
    }

    public void AmenitiesModule(View view) {
      startActivity(new Intent(getApplicationContext(), Amenities_MainActivity.class));
        //Toast.makeText(this,"Opening Amenities Module", Toast.LENGTH_SHORT).show();
    }

    public void ComplaintsModule(View view) {
        Toast.makeText(this,"Opening Complaints Module", Toast.LENGTH_SHORT).show();
    }

    public void StaffModule(View view) {
        Toast.makeText(this,"Opening Staff Module", Toast.LENGTH_SHORT).show();
    }

    public void GateKeeperModule(View view) {
        Toast.makeText(this,"Opening GateKeeper Module", Toast.LENGTH_SHORT).show();
    }

    public void TenantModule(View view) {
        Toast.makeText(this,"Opening Tenant Module", Toast.LENGTH_SHORT).show();
    }

    public void LostNFoundModule(View view) {
        Toast.makeText(this,"Opening Lost/Found Module", Toast.LENGTH_SHORT).show();
    }
}
