package com.example.smartsociety;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class AmenitiesInfo extends AppCompatActivity {
    ImageView img;
    TextView txt_name;
    TextView txt_desc;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amenities_info);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        img=findViewById(R.id.imgCircled);
        txt_name=findViewById(R.id.amenitie);
        txt_desc=findViewById(R.id.amenitie_des);
        Intent intent=getIntent();
        id=intent.getIntExtra("id",0);
        GETDATA();
    }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    void GETDATA(){
        String URL="http://52.66.187.237:3000/adminAmenities/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(AmenitiesInfo.this, "Empty ji", Toast.LENGTH_LONG).show();
                }else {
                    Log.e("HELLO", response);

                        try {
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            String path="http://52.66.187.237:3000/amenities"+jsonObject.getString("am_image_path");
                            txt_name.setText(jsonObject.getString("am_name"));
                            txt_desc.setText(jsonObject.getString("am_description"));
                            ImageLoader imageLoader= MySingleton.getInstance(AmenitiesInfo.this).getImageLoader();
                            imageLoader.get(path, new ImageLoader.ImageListener() {
                                public void onErrorResponse(VolleyError error) {
                                    img.setImageResource(R.drawable.ic_launcher_background);
                                }

                                public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                                    if (response.getBitmap() != null) {
                                        img.setImageBitmap(response.getBitmap());
                                    }
                                }
                            });
                        } catch (JSONException e) {
                            Toast.makeText(AmenitiesInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
                            System.out.println("Err message is  "+e.getMessage());
                            e.printStackTrace();
                        }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(AmenitiesInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
}
