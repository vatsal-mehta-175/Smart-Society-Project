package com.example.smartsociety;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

public class Amenitie {
    private String name;
    private String image;
    private String des;
    private int ID;
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }



    public Amenitie(String name,String image,String des,int ID){
        this.name=name;
        this.image=image;
        this.des=des;
        this.ID=ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public String getDes() { return des; }

    public void setDes(String des) { this.des = des; }
}
