package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;

import java.util.ArrayList;

public class AmenitieAdapter extends RecyclerView.Adapter<AmenitieAdapter.AmenitieRowHolder>{
    ArrayList<Amenitie>amenitieData;
    Context context;
    MyClickInterface myClickInterface;
    public AmenitieAdapter(ArrayList<Amenitie>amenitieData,Context context,MyClickInterface myClickInterface){
        this.context=context;
        this.amenitieData=amenitieData;
        this.myClickInterface=myClickInterface;
    }
    @NonNull
    @Override
    public AmenitieRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.amenities_row,parent,false);
        return new AmenitieRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AmenitieRowHolder holder, int position) {
        holder.txtAmenitieName.setText(amenitieData.get(position).getName());
        ImageLoader imageLoader=MySingleton.getInstance(context).getImageLoader();
        imageLoader.get(amenitieData.get(position).getImage(), new ImageLoader.ImageListener() {
            public void onErrorResponse(VolleyError error) {
                holder.imgAmenities.setImageResource(R.drawable.ic_launcher_background);
            }

            public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                if (response.getBitmap() != null) {
                    holder.imgAmenities.setImageBitmap(response.getBitmap());
                }
            }
        });
        //holder.imgAmenities.setImageBitmap();
    }

    @Override
    public int getItemCount() {
        return amenitieData.size();
    }
    class AmenitieRowHolder extends RecyclerView.ViewHolder{
        TextView txtAmenitieName;
        ImageView imgAmenities;
        ImageButton btn_delete;
        public AmenitieRowHolder(@NonNull View itemView) {
            super(itemView);
            txtAmenitieName=itemView.findViewById(R.id.txt_amenite_name);
            imgAmenities=itemView.findViewById(R.id.img_amenite);
            btn_delete=itemView.findViewById(R.id.btn_delete_a);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });
            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }
    interface MyClickInterface{
        void onItemClick(int postionOfTheAmenitie);
        void onDelteClick(int postionOfTheAmenitie);
    }
}
