package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class VisitorExitActivity extends AppCompatActivity {
  EditText fname,lname,house,contact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_exit);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        fname=(EditText) findViewById(R.id.v_fname);
        fname.setText("Deeksha");
        lname=(EditText) findViewById(R.id.v_lname);
      lname.setText("Jain");
      house=(EditText) findViewById(R.id.v_house);
      house.setText("a101");
      contact=(EditText) findViewById(R.id.v_phone);
      contact.setText("Deeksha");
    }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    public void exitVisitor(View view) {
        Toast.makeText(this,"Visitor Exit Invoked", Toast.LENGTH_SHORT).show();
    }
    //three dots code ends

}
