package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
public class LostandFoundInfo extends AppCompatActivity {
    ImageView img;
    TextView txt_name;
    TextView txt_desc;
    TextView txt_type;
    Spinner dropdown;
    Button edit;
    Button update;
    Button cancle;
    int id=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lostand_found_info);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        img=findViewById(R.id.lf_imgCircled);
        txt_name=findViewById(R.id.lf_name);
        txt_desc=findViewById(R.id.lf_des);
        txt_type=findViewById(R.id.lf_type);
        dropdown=findViewById(R.id.lf_Status);
        edit=findViewById(R.id.lf_edit);
        update=findViewById(R.id.lf_update);
        cancle=findViewById(R.id.lf_Cancle_update);
        String[] items = new String[]{"Active", "Resolved"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);
        disable();
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setEnabled(false);
                edit.animate().alpha(0).start();
                update.setEnabled(true);
                update.animate().alpha(1).start();
                cancle.setEnabled(true);
                cancle.animate().alpha(1).start();
                dropdown.animate().alpha(1).start();
                dropdown.setEnabled(true);
            }
        });
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disable();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                putdata();
            }
        });
//        Intent intent=getIntent();
//        id=intent.getIntExtra("id",0);
        GETDATA();
    }
    void GETDATA(){
        String URL="http://52.66.187.237:3000/lost_and_found/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(LostandFoundInfo.this, "Empty ji", Toast.LENGTH_LONG).show();
                }else {
                    Log.e("HELLO", response);

                    try {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        if(jsonObject.getString("i_file_path")!=null){
                            String path="http://52.66.187.237:3000/lost_and_found"+jsonObject.getString("i_file_path");
                            ImageLoader imageLoader=MySingleton.getInstance(LostandFoundInfo.this).getImageLoader();
                            imageLoader.get(path, new ImageLoader.ImageListener() {
                                public void onErrorResponse(VolleyError error) {
                                    img.setImageResource(R.drawable.ic_launcher_background);
                                }

                                public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                                    if (response.getBitmap() != null) {
                                        img.setImageBitmap(response.getBitmap());
                                    }
                                }
                            });

                        }
                        txt_name.setText(jsonObject.getString("i_name"));
                        txt_desc.setText(jsonObject.getString("i_description"));
                        if(jsonObject.getInt("i_type")!=0){
                            txt_type.setText("Found");
                        }else{txt_type.setText("Lost");}

                    } catch (JSONException e) {
                        Toast.makeText(LostandFoundInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
                        System.out.println("Err message is  "+e.getMessage());
                        e.printStackTrace();
                    }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(LostandFoundInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void putdata(){
        String URL="http://52.66.187.237:3000/lost_and_found/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(LostandFoundInfo.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(LostandFoundInfo.this, "Success", Toast.LENGTH_LONG).show();
                    disable();
                    Intent intent = new Intent(getApplicationContext(), LostandFoundInfo.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(LostandFoundInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();

                if(dropdown.getSelectedItem().toString().matches("Resolved")){params.put("status","1");}
                else{params.put("status","0");}

                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void disable(){
        edit.setEnabled(true);
        edit.animate().alpha(1).start();
        update.setEnabled(false);
        update.animate().alpha(0).start();
        cancle.setEnabled(false);
        cancle.animate().alpha(0).start();
        dropdown.animate().alpha(0).start();
        dropdown.setEnabled(false);
    }
}
