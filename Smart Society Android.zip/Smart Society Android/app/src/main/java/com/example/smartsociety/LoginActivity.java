package com.example.smartsociety;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {

  //Retrieving values
  EditText id;
  EditText password;
  String selectedRadioButton="";


  // final String url_Login = "52.66.187.237:3000/adminlogin"; //api url  provided by vatsal

  @Override
  protected void onCreate(Bundle savedInstanceState) {


    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    getSupportActionBar().hide();
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    TextView mytext = (TextView) findViewById(R.id.hint);
    mytext.setVisibility(View.GONE);
    id = (EditText)findViewById(R.id.username);
    password = (EditText)findViewById(R.id.password);
  }

  public void btn_signupForm(View view) {
    //startActivity(new Intent(getApplicationContext(), SignupActivity.class));
    startActivity(new Intent(getApplicationContext(), SignupActivity.class));
  }


  public void onRadioButtonClicked(View view) {
    boolean checked = ((RadioButton) view).isChecked();
    TextView mytext = (TextView) findViewById(R.id.hint);
    if (view.getId() == R.id.resident && checked) {
      selectedRadioButton="resident";
      mytext.setVisibility(View.VISIBLE);
    }
    else if(view.getId() == R.id.admin && checked){
      selectedRadioButton="admin";
      mytext.setVisibility(View.GONE);
    }
    else if(view.getId() == R.id.tenant && checked){
      selectedRadioButton="tenant";
      mytext.setVisibility(View.GONE);
    }
    else if(view.getId() == R.id.gatekeeper && checked){
      selectedRadioButton="gatekeeper";
      mytext.setVisibility(View.GONE);
    }

  }
  //only for testing purpose
  public void test_dashboard(View view) {
     /* RequestQueue requestQueue;

      // Instantiate the cache
      Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB cap

      // Set up the network to use HttpURLConnection as the HTTP client.
      Network network = new BasicNetwork(new HurlStack());

// Instantiate the RequestQueue with the cache and network.
      requestQueue = new RequestQueue(cache, network);

// Start the queue
      requestQueue.start();*/
    String URL="";

    if(selectedRadioButton.equals("admin")) {
      URL = "http://52.66.187.237:3000/adminlogin";
      Log.e("HELLO", "URL = " + URL);
    }
    else if(selectedRadioButton.equals("resident")){
      URL = "http://52.66.187.237:3000/residenceLogin";
      Log.e("HELLO", "URL = " + URL);
    }

    else if(selectedRadioButton.equals("tenant")){
      URL = "http://52.66.187.237:3000/tenantLogin";
      Log.e("HELLO", "URL = " + URL);
    }

    else if(selectedRadioButton.equals("gatekeeper")){
      URL = "http://52.66.187.237:3000/gateLogin";
      Log.e("HELLO", "URL = " + URL);
    }


    StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
      @Override
      public void onResponse(String response) {
        Log.e("HELLO", response);

        if (response.charAt(1) == '0') {
          Toast.makeText(LoginActivity.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
        } else {

          Intent intent;

          if(selectedRadioButton.equals("admin"))
            intent = new Intent(getApplicationContext(), AdminDashboardActivity.class);
          else if(selectedRadioButton.equals("resident"))
            intent = new Intent(getApplicationContext(), ResidentDashboardActivity.class);
          else if(selectedRadioButton.equals("tenant"))
            intent = new Intent(getApplicationContext(), TenantDashboardActivity.class);
          else
            intent = new Intent(getApplicationContext(), GateKeeperDashboardActivity.class);

          startActivity(intent);
          finish();
        }

            /*JSONArray jsonArray = new JSONArray(response);
            if (jsonArray.length() == 0) {
              Toast.makeText(LoginActivity.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
            } else {
              Log.e("HELLO", response);
              String userPhoneNumber = "", userName = "", userTypeId = "";
              JSONObject jsonObject1 = jsonArray.getJSONObject(0);
              userPhoneNumber = jsonObject1.getString("userPhoneNumber");
              userName = jsonObject1.getString("userName");
              userTypeId = jsonObject1.getString("userTypeId");
              String type = jsonObject1.getString("name");
              editor.putString("userPhoneNumber", userPhoneNumber);
              editor.putString("userName", userName);
              editor.putString("userTypeId", userTypeId);
              editor.putString("type", type);
              Log.e("LOGIN",type);
              editor.commit();

              Intent intent;
              if (type.equals("secretary")) {
                intent = new Intent(LoginActivity.this, SecretaryActivity.class);
              } else if (type.equals("user")) {
                intent = new Intent(LoginActivity.this, UserActivity.class);
              } else {
                intent = new Intent(LoginActivity.this, LoginActivity.class);
              }
              intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
              intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
              startActivity(intent);
              finish();
            }*/

      }
    }, new Response.ErrorListener() {
      @Override
      public void onErrorResponse(VolleyError error) {
        Log.e("HELLO", "ERROR" + error.toString());
        Toast.makeText(LoginActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
      }
    }){
      @Override
      protected Map<String, String> getParams() throws AuthFailureError {

        Map<String,String> params = new HashMap<>();

        params.put("id",id.getText().toString());
        params.put("password",password.getText().toString());

        return params;
      }
    };

    MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    //requestQueue.add(stringRequest);



    //  startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));

    //startActivity(new Intent(getApplicationContext(), ResidentDashboardActivity.class));

    //startActivity(new Intent(getApplicationContext(), TenantDashboardActivity.class));

    //startActivity(new Intent(getApplicationContext(), GateKeeperDashboardActivity.class));
//        startActivity(new Intent(getApplicationContext(), StaffRegistrationActivity.class));
  }

}

//    public void onclick(View view) {
//
//        //storing values in varaibles
//        String username = txtname.getText().toString();
//        String password = txtpass.getText().toString();
//        if (username.length() == 0)
//            Toast.makeText(this, "Username should not be empty", Toast.LENGTH_SHORT).show();
//        if (password.length() == 0)
//            Toast.makeText(this, "Password should not be empty", Toast.LENGTH_SHORT).show();
//        if (password.length() < 8)
//            Toast.makeText(this, "Password should be minimum 8 characters long", Toast.LENGTH_SHORT).show();
//
//
//
//
//    }
