package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TenantUpdateDeleteActivity extends AppCompatActivity {
  EditText fname;
  EditText lname;
  EditText phone;
  EditText email;
  Button updatebtn;
  Context context = this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_update_delete);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

      fname =findViewById(R.id.t_fname);
      lname =findViewById(R.id.t_lname);
      phone =findViewById(R.id.t_contact);
      email=findViewById(R.id.t_email);
      updatebtn=findViewById(R.id.btnupdate);
      GETDATA();

      updatebtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          if (fname.getText().toString().matches("") || lname.getText().toString().matches("") || phone.getText().toString().matches("")||
                  email.getText().toString().matches("")) {
            Toast.makeText( TenantUpdateDeleteActivity.this, "Please Fill all the values", Toast.LENGTH_SHORT).show();
          } else {
            if (phone.getText().toString().length() != 10) {
              Toast.makeText(TenantUpdateDeleteActivity.this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
            } else {
              PUTDATA();
            }
          }
        }
      });

    }
  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        //Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(),TenantUpdateDeleteActivity.class));
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends

  void GETDATA(){
    SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
    String id = sharedPreferences.getString("tt", "defaultValue");
    int tId=Integer.parseInt(id);
    Toast.makeText(TenantUpdateDeleteActivity.this, "ID"+tId, Toast.LENGTH_LONG).show();
    String URL="http://52.66.187.237:3000/tenant/"+tId;
    StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
      @Override
      public void onResponse(String response) {
        Log.e("HELLO", response);
        JSONArray jsonArray = null;
        try {
          jsonArray = new JSONArray(response);
        } catch (JSONException e) {
          e.printStackTrace();
        }

               try {
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            fname.setText(jsonObject.getString("t_fname"));
            lname.setText(jsonObject.getString("t_lname"));
            phone.setText(jsonObject.getString("t_phone"));
            email.setText(jsonObject.getString("t_email"));

          } catch (JSONException e) {
            Toast.makeText(TenantUpdateDeleteActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            System.out.println("Err message is  "+e.getMessage());
            e.printStackTrace();
          }

        }

    }, new Response.ErrorListener() {
      @Override
      public void onErrorResponse(VolleyError error) {
        Log.e("HELLO", "ERROR" + error.toString());
        Toast.makeText(TenantUpdateDeleteActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
      }
    });

    MySingleton.getInstance(this).addToRequestQueue(stringRequest);
  }

  void PUTDATA(){
    SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
    String id = sharedPreferences.getString("tt", "defaultValue");
    String URL="http://52.66.187.237:3000/tenant/"+id;
    StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
      @Override
      public void onResponse(String response) {
        Log.e("HELLO", response);

        if (response.charAt(1) == '0') {
          Toast.makeText(TenantUpdateDeleteActivity.this, "Cannot Update", Toast.LENGTH_LONG).show();
        } else {
          System.out.println(response);
          Toast.makeText(TenantUpdateDeleteActivity.this, "Profile Updated Successfully", Toast.LENGTH_LONG).show();
          Intent intent = new Intent(getApplicationContext(), TenantDashboardActivity.class);
          startActivity(intent);
          finish();
        }
      }
    }, new Response.ErrorListener() {
      @Override
      public void onErrorResponse(VolleyError error) {
        Log.e("HELLO", "ERROR" + error.toString());
        Toast.makeText(TenantUpdateDeleteActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
      }
    }){
      @Override
      protected Map<String, String> getParams() throws AuthFailureError {

        Map<String,String> params = new HashMap<>();
        params.put("t_name",fname.getText().toString());
        params.put("t_lname",lname.getText().toString());
        params.put("t_phone",phone.getText().toString());
        params.put("t_email",email.getText().toString());
        return params;
      }
    };

    MySingleton.getInstance(this).addToRequestQueue(stringRequest);
  }
}
