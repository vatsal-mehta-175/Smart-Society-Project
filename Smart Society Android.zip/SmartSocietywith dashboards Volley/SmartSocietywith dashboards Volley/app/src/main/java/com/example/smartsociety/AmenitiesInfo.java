package com.example.smartsociety;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class AmenitiesInfo extends AppCompatActivity {
    ImageView img;
    TextView txt_name;
    TextView txt_desc;
    int id;
    //new
    Spinner dropdown;
    Button EDIT;
    Button update;
    Button cancle;
    String type;
    //new end
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amenities_info);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        img=findViewById(R.id.imgCircled);
        txt_name=findViewById(R.id.amenitie);
        txt_desc=findViewById(R.id.amenitie_des);
        SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
       type = sharedPreferences.getString("type", "defaultValue");
        EDIT=findViewById(R.id.btn_edit_am);

        //new
        dropdown=findViewById(R.id.dd_Status_am);
        String[] items = new String[]{"Available", "UnAvailable"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);
        update=findViewById(R.id.btn_update_am);
        cancle=findViewById(R.id.btn_cancle_am);

        EDIT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enable();
            }
        });
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disable();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txt_desc.getText().toString().matches("")){
                    Toast.makeText(AmenitiesInfo.this, "Please Enter the Description", Toast.LENGTH_LONG).show();
                }
                else{
                    PUTDATA();}
            }
        });
        disable();
        if(!type.equals("admin")){

            EDIT.animate().alpha(0).start();
            EDIT.setEnabled(false);
        }
        //new end
        Intent intent=getIntent();
        id=intent.getIntExtra("id",0);
        GETDATA();
    }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
    void GETDATA(){
        String URL="http://52.66.187.237:3000/adminAmenities/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(AmenitiesInfo.this, "Empty ji", Toast.LENGTH_LONG).show();
                }else {
                    Log.e("HELLO", response);

                        try {
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            String path="http://52.66.187.237:3000/amenities"+jsonObject.getString("am_image_path");
                            txt_name.setText(jsonObject.getString("am_name"));
                            txt_desc.setText(jsonObject.getString("am_description"));
                            ImageLoader imageLoader= MySingleton.getInstance(AmenitiesInfo.this).getImageLoader();
                            imageLoader.get(path, new ImageLoader.ImageListener() {
                                public void onErrorResponse(VolleyError error) {
                                    img.setImageResource(R.drawable.ic_launcher_background);
                                }

                                public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                                    if (response.getBitmap() != null) {
                                        img.setImageBitmap(response.getBitmap());
                                    }
                                }
                            });
                        } catch (JSONException e) {
                            Toast.makeText(AmenitiesInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
                            System.out.println("Err message is  "+e.getMessage());
                            e.printStackTrace();
                        }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(AmenitiesInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    public void btn_BackForm(View view) {
        startActivity(new Intent(getApplicationContext(), Amenities_MainActivity.class));
    }
    void disable(){
        EDIT.animate().alpha(1).start();
        EDIT.setEnabled(true);
        update.animate().alpha(0).start();
        update.setEnabled(false);
        cancle.animate().alpha(0).start();
        cancle.setEnabled(false);
        dropdown.animate().alpha(0).start();
        dropdown.setEnabled(false);
        txt_desc.setEnabled(false);

    }
    void enable(){
        EDIT.animate().alpha(0).start();
        EDIT.setEnabled(false);
        update.animate().alpha(1).start();
        update.setEnabled(true);
        cancle.animate().alpha(1).start();
        cancle.setEnabled(true);
        dropdown.animate().alpha(1).start();
        dropdown.setEnabled(true);
        txt_desc.setEnabled(true);
    }
    void PUTDATA(){
        String URL="http://52.66.187.237:3000/adminAmenities/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(AmenitiesInfo.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(AmenitiesInfo.this, "Success", Toast.LENGTH_LONG).show();
                    disable();
                    Intent intent = new Intent(getApplicationContext(), Amenities_MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(AmenitiesInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();
                params.put("am_description",txt_desc.getText().toString());
                if(dropdown.getSelectedItem().toString().matches("Available")){params.put("am_status","1");}
                else{params.put("am_status","0");}

                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }
}
