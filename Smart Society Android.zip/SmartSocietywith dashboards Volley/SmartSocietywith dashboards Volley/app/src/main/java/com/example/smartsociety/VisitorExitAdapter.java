package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class VisitorExitAdapter extends RecyclerView.Adapter<VisitorExitAdapter.VisitorExitRowHolder> {
    ArrayList<Visitor> VisitorData;
    Context context;
    VisitorExitAdapter.MyClickInterface myClickInterface;



    public VisitorExitAdapter(ArrayList<Visitor> VisitorData, Context context, VisitorExitAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.VisitorData = VisitorData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public VisitorExitAdapter.VisitorExitRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.visitor_exit_row, parent, false);
        return new VisitorExitAdapter.VisitorExitRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VisitorExitAdapter.VisitorExitRowHolder holder, int position) {
        holder.txtVName.setText(VisitorData.get(position).getFname()+" "+VisitorData.get(position).getLname());
        holder.txtVhouse.setText( VisitorData.get(position).getRhouse());
        holder.txtEntry.setText( VisitorData.get(position).getEntry());
        holder.txtExit.setText( VisitorData.get(position).getExit());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return VisitorData.size();
    }

    class VisitorExitRowHolder extends RecyclerView.ViewHolder {
        TextView txtVName;
        TextView txtVhouse;
        TextView txtEntry;
        TextView txtExit;


        public VisitorExitRowHolder(@NonNull View itemView) {
            super(itemView);
            txtVName = itemView.findViewById(R.id.txt_v_name);
            txtVhouse = itemView.findViewById(R.id.txt_v_house);
            txtEntry = itemView.findViewById(R.id.txt_ventry);
            txtExit = itemView.findViewById(R.id.txt_vexit);



        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheStaff);


    }

}
