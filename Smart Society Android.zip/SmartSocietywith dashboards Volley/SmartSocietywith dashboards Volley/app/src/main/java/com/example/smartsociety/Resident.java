package com.example.smartsociety;

public class Resident {
    private String first;
    private String last;
    private String rhouse;
    private String phone;




    public Resident(String first,String last,String rhouse,String phone){
        this.first=first;
        this.last=last;
        this.rhouse =rhouse;
        this.phone=phone;

    }
    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getRhouse() {
        return rhouse;
    }

    public void setRhouse(String rhouse) {
        this.rhouse = rhouse;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }



}
