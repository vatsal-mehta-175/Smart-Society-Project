package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class TenantRegistrationActivity extends AppCompatActivity {

    EditText fname;
    EditText lname;
    EditText phone;
    EditText email;
    EditText password;
    Button addbtn;
    Context context = this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_registration);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        System.out.println("testing ver");
      fname =findViewById(R.id.t_first);
      lname =findViewById(R.id.t_last);
      phone =findViewById(R.id.t_contact);
      email=findViewById(R.id.t_email);
      password=findViewById(R.id.t_password);
      addbtn=findViewById(R.id.btn_add);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fname.getText().toString().matches("") || lname.getText().toString().matches("") || phone.getText().toString().matches("")||
                        email.getText().toString().matches("") || password.getText().toString().matches("")) {
                    Toast.makeText( TenantRegistrationActivity.this, "Please Fill all the values", Toast.LENGTH_SHORT).show();
                } else {
                    if (phone.getText().toString().length() != 10) {
                        Toast.makeText(TenantRegistrationActivity.this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
                    } else {
                        POSTDATA();
                    }
                }
                }
        });
    }
  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
          return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
  void POSTDATA(){
      String URL="http://52.66.187.237:3000/tenant";
      StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
          @Override
          public void onResponse(String response) {
              Log.e("HELLO", response);

              if (response.charAt(1) == '0') {
                  Toast.makeText(TenantRegistrationActivity.this, "Invalid", Toast.LENGTH_LONG).show();
              } else {
                  System.out.println(response);
                  Toast.makeText(TenantRegistrationActivity.this, "Successfully Added", Toast.LENGTH_LONG).show();
                  Intent intent = new Intent(getApplicationContext(), Tenant_MainActivity.class);
                  startActivity(intent);
                  finish();
              }
          }
      }, new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError error) {
              Log.e("HELLO", "ERROR" + error.toString());
              Toast.makeText(TenantRegistrationActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
          }
      }){
          @Override
          protected Map<String, String> getParams() throws AuthFailureError {

              Map<String,String> params = new HashMap<>();
              params.put("t_fname",fname.getText().toString());
              params.put("t_lname",lname.getText().toString());
              params.put("t_phone",phone.getText().toString());
              params.put("t_password",password.getText().toString());
              params.put("t_email",email.getText().toString());

              SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
              String id = sharedPreferences.getString("id", "defaultValue");

              params.put("r_house", id);

              return params;
          }
      };

      MySingleton.getInstance(this).addToRequestQueue(stringRequest);
  }
}
