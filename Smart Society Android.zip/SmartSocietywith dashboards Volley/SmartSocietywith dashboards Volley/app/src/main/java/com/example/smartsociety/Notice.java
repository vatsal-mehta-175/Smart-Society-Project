package com.example.smartsociety;

public class Notice {
    private String name;
    private String pdf;
    private String Admin_id;
    private String Date;
    private int ID;
    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }



    public Notice(String name,String pdf,String Admin_id,int ID,String Date){
        this.name=name;
        this.pdf =pdf;
        this.Admin_id =Admin_id;
        this.Date=Date;
        this.ID=ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }
    public String getAdmin_id() { return Admin_id; }

    public void setAdmin_id(String admin_id) { this.Admin_id = admin_id; }
}
