package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class StaffUpdateActivity extends AppCompatActivity {

    EditText fname, lname, phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_update);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        fname = (EditText) findViewById(R.id.staff_first);
        lname = (EditText) findViewById(R.id.staff_last);
        phone = (EditText) findViewById(R.id.staff_contact);


        GETDATA();


    }

    void GETDATA() {
        Bundle extras = getIntent().getExtras();
        int value = -1;
        if (extras != null) {
            value = extras.getInt("id");
            Toast.makeText(StaffUpdateActivity.this, "ID" + value, Toast.LENGTH_LONG).show();

        }
        //The key argument here must match that used in the other activity

        String URL = "http://52.66.187.237:3000/staff/" + value;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    fname.setText(jsonObject.getString("s_fname"));
                    lname.setText(jsonObject.getString("s_lname"));

                    phone.setText(jsonObject.getString("s_phone"));

                } catch (JSONException e) {
                    Toast.makeText(StaffUpdateActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
                    System.out.println("Err message is  " + e.getMessage());
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(StaffUpdateActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    //three dots code starts
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.three_dots_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile:
                Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.logout:
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.changePass:
                startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    //three dots code ends
    public void updateStaff(View view) {

        if (fname.getText().toString().matches("") || lname.getText().toString().matches("") || phone.getText().toString().matches("")) {
            Toast.makeText(this, "Please Fill all the values", Toast.LENGTH_SHORT).show();
        } else {
            if (phone.getText().toString().length() != 10) {
                Toast.makeText(this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
            } else {

                //code for update

                Bundle extras = getIntent().getExtras();
                int value = -1;
                if (extras != null) {
                    value = extras.getInt("id");
                    Toast.makeText(StaffUpdateActivity.this, "ID" + value, Toast.LENGTH_LONG).show();

                }
                //The key argument here must match that used in the other activity

                String URL = "http://52.66.187.237:3000/staff/" + value;
                StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("HELLO", response);

                        if (response.charAt(1) == '0') {
                            Toast.makeText(StaffUpdateActivity.this, "Cannot Update", Toast.LENGTH_LONG).show();
                        } else {
                            System.out.println(response);
                            Toast.makeText(StaffUpdateActivity.this, "Staff Details Updated Successfully", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(getApplicationContext(), Staff_MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("HELLO", "ERROR" + error.toString());
                        Toast.makeText(StaffUpdateActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {

                        Map<String, String> params = new HashMap<>();
                        params.put("s_fname", fname.getText().toString());
                        params.put("s_lname", lname.getText().toString());
                        params.put("s_phone", phone.getText().toString());

                        return params;
                    }
                };

                MySingleton.getInstance(this).addToRequestQueue(stringRequest);
            }


        }
    }
}
