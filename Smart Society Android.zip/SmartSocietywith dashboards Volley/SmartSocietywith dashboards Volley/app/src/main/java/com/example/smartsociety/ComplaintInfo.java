package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
public class ComplaintInfo extends AppCompatActivity {
    ImageView img;
    TextView txt_name;
    TextView txt_desc;
    TextView txt_house;
    TextView txt_comments;
    Spinner dropdown;
    Button edit;
    Button update;
    Button cancle;
    EditText comment;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_info);
      getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        img=findViewById(R.id.com_imgCircled);
        txt_name=findViewById(R.id.com_name);
        txt_desc=findViewById(R.id.com_des);
        txt_house=findViewById(R.id.com_house);
        dropdown=findViewById(R.id.com_Status);
        edit=findViewById(R.id.com_edit);
        update=findViewById(R.id.com_update);
        cancle=findViewById(R.id.com_Cancle_update);
        comment=findViewById(R.id.com_comments);
        txt_comments=findViewById(R.id.com_com_nonedit);
        String[] items = new String[]{"Active", "Resolved"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);
        disable();
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setEnabled(false);
                edit.animate().alpha(0).start();
                update.setEnabled(true);
                update.animate().alpha(1).start();
                cancle.setEnabled(true);
                cancle.animate().alpha(1).start();
                dropdown.animate().alpha(1).start();
                dropdown.setEnabled(true);
                comment.setEnabled(true);
                comment.animate().alpha(1).start();
            }
        });
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disable();
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                putdata();
            }
        });
        Intent intent=getIntent();
        id=intent.getIntExtra("id",0);
        SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
        String type = sharedPreferences.getString("type", "defaultValue");
        if(!type.equals("admin")){
           no_edit();
        }
        GETDATA();
    }


  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        Toast.makeText(this, "Change Password", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends

    void GETDATA(){
        String URL="http://52.66.187.237:3000/admin_complaint/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(ComplaintInfo.this, "Empty ji", Toast.LENGTH_LONG).show();
                }else {
                    Log.e("HELLO", response);

                    try {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        if(jsonObject.getString("c_file_path")!=null){
                            String path="http://52.66.187.237:3000/complaints"+jsonObject.getString("c_file_path");
                            ImageLoader imageLoader=MySingleton.getInstance(ComplaintInfo.this).getImageLoader();
                            imageLoader.get(path, new ImageLoader.ImageListener() {
                                public void onErrorResponse(VolleyError error) {
                                    img.setImageResource(R.drawable.ic_launcher_background);
                                }

                                public void onResponse(ImageLoader.ImageContainer response, boolean arg1) {
                                    if (response.getBitmap() != null) {
                                        img.setImageBitmap(response.getBitmap());
                                    }
                                }
                            });

                        }
                        if(jsonObject.getInt("c_status")==1){
                            no_edit();
                        }
                        txt_name.setText(jsonObject.getString("c_name"));
                        txt_desc.setText(jsonObject.getString("c_description"));
                        txt_house.setText(jsonObject.getString("r_house"));
                        txt_comments.setText(jsonObject.getString("c_comments"));

                    } catch (JSONException e) {
                        Toast.makeText(ComplaintInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
                        System.out.println("Err message is  "+e.getMessage());
                        e.printStackTrace();
                    }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(ComplaintInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void putdata(){
        String URL="http://52.66.187.237:3000/admin_complaint/"+id;
        StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(ComplaintInfo.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(ComplaintInfo.this, "Success", Toast.LENGTH_LONG).show();
                    disable();
                    Intent intent = new Intent(getApplicationContext(), Complaints_MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(ComplaintInfo.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<>();
                params.put("c_comments",comment.getText().toString());
                params.put("a_id","admin@smartsociety");
                if(dropdown.getSelectedItem().toString().matches("Resolved")){params.put("c_status","1");}
                else{params.put("c_status","0");}

                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void disable(){
        edit.setEnabled(true);
        edit.animate().alpha(1).start();
        update.setEnabled(false);
        update.animate().alpha(0).start();
        cancle.setEnabled(false);
        cancle.animate().alpha(0).start();
        dropdown.animate().alpha(0).start();
        dropdown.setEnabled(false);
        comment.setEnabled(false);
        comment.animate().alpha(0).start();

    }
    public void no_edit(){
        edit.animate().alpha(0).start();
        edit.setEnabled(false);
    }
}
