package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.app.VoiceInteractor;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText apartment_no, f_name,l_name, contact , pass,confirmpass;
    Spinner block;
    String blockhouse;
  Button btnSignup;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Spinner spinner =findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.block_numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        block=findViewById(R.id.spinner1);
        blockhouse = block.getSelectedItem().toString();

        apartment_no=findViewById(R.id.apartment);

        f_name=findViewById(R.id.first);
        l_name=findViewById(R.id.last);
        contact=findViewById(R.id.contactno);
        pass=findViewById(R.id.password);
        confirmpass=findViewById(R.id.confirmpassword);


        btnSignup=findViewById(R.id.registerbtn);
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if( f_name.getText().toString().matches("") ||l_name.getText().toString().matches("")|| contact.getText().toString().matches("") || confirmpass.getText().toString().matches("") ||pass.getText().toString().matches("")|| blockhouse.matches("") ||apartment_no.getText().toString().matches("")){



                    Toast.makeText(SignupActivity.this,"Please Fill all the values",Toast.LENGTH_SHORT).show();

                }else{
                    if(!confirmpass.getText().toString().matches(pass.getText().toString())) {
                        System.out.println(pass);
                        System.out.println(confirmpass);
                        Toast.makeText(SignupActivity.this, "Password should match confirm password", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                       System.out.println(apartment_no.getText().toString());
                       POSTDATA();
                    }

                }
            }
        });






    }

    void POSTDATA(){
        String URL="http://52.66.187.237:3000/resident";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(SignupActivity.this, "Invalid username or password or role", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(SignupActivity.this, "Verification Pending", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(SignupActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();

                params.put("fname",f_name.getText().toString());
                params.put("lname",l_name.getText().toString());

                params.put("phone",contact.getText().toString());

                params.put("password",pass.getText().toString());
                params.put("id",blockhouse+""+apartment_no.getText().toString());

                return params;




            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
         blockhouse=parent.getItemAtPosition(position).toString();
        //Toast.makeText(parent.getContext(),block,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent)
    {

    }

    public void btn_LoginForm(View view)
    {
        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
    }
}