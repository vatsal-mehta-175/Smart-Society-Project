package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class VisitorAdapter extends RecyclerView.Adapter<VisitorAdapter.VisitorRowHolder> {
    ArrayList<Visitor> VisitorData;
    Context context;
    VisitorAdapter.MyClickInterface myClickInterface;



    public VisitorAdapter(ArrayList<Visitor> VisitorData, Context context, VisitorAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.VisitorData = VisitorData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public VisitorAdapter.VisitorRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.visitor_entry_row, parent, false);
        return new VisitorAdapter.VisitorRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VisitorAdapter.VisitorRowHolder holder, int position) {
        holder.txtStaffName.setText(VisitorData.get(position).getFname()+" "+VisitorData.get(position).getLname());
        holder.txtstaffhouse.setText( VisitorData.get(position).getRhouse());
        holder.txtstaffstart.setText( VisitorData.get(position).getEntry());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return VisitorData.size();
    }

    class VisitorRowHolder extends RecyclerView.ViewHolder {
        TextView txtStaffName;
        TextView txtstaffhouse;
        TextView txtstaffstart;
        Button btn_exit;

        public VisitorRowHolder(@NonNull View itemView) {
            super(itemView);
            txtStaffName = itemView.findViewById(R.id.txt_v_name);
            txtstaffhouse = itemView.findViewById(R.id.txt_v_house);
            txtstaffstart = itemView.findViewById(R.id.txt_v_time);
            btn_exit = itemView.findViewById(R.id.btn_exit);


            btn_exit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheStaff);

        void onDelteClick(int positionOfTheStaff);
    }

}
