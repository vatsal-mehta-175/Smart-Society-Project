package com.example.smartsociety;

import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.StringRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class NoticeAdapter extends RecyclerView.Adapter<NoticeAdapter.NoticeRowHolder>{
    ArrayList<Notice> noticeData;
    Context context;
    NoticeAdapter.MyClickInterface myClickInterface;
    public NoticeAdapter(ArrayList<Notice>noticeData, Context context, NoticeAdapter.MyClickInterface myClickInterface){
        this.context=context;
        this.noticeData=noticeData;
        this.myClickInterface=myClickInterface;
    }
    @NonNull
    @Override
    public NoticeAdapter.NoticeRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.notice_row,parent,false);
        return new NoticeAdapter.NoticeRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoticeAdapter.NoticeRowHolder holder, int position) {
        holder.txtNoticeName.setText(noticeData.get(position).getName());
        holder.txtNoticeDate.setText(noticeData.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        return noticeData.size();
    }
    class NoticeRowHolder extends RecyclerView.ViewHolder{
        TextView txtNoticeName;
        TextView txtNoticeDate;

        public NoticeRowHolder(@NonNull View itemView) {
            super(itemView);
            txtNoticeName =itemView.findViewById(R.id.txt_notice_name);
            txtNoticeDate=itemView.findViewById(R.id.txt_date);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });

        }
    }
    interface MyClickInterface{
        void onItemClick(int postionOfTheAmenitie);

    }

}
