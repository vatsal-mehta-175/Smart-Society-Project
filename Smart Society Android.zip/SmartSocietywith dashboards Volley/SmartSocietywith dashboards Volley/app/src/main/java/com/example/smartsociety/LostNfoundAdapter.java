package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LostNfoundAdapter extends RecyclerView.Adapter<LostNfoundAdapter.LostNfoundRowHolder> {
    ArrayList<LostNFound> itemsData;
    Context context;
    LostNfoundAdapter.MyClickInterface myClickInterface;


    public LostNfoundAdapter(ArrayList<LostNFound> itemsData, Context context, LostNfoundAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.itemsData = itemsData;
        this.myClickInterface = myClickInterface;
    }
    @NonNull
    @Override
    public LostNfoundAdapter.LostNfoundRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.lostnfound_row, parent, false);
        return new LostNfoundAdapter.LostNfoundRowHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull  LostNfoundAdapter.LostNfoundRowHolder holder, int position) {
        holder.txtItemName.setText(itemsData.get(position).getName());
        holder.txtItemStatus.setText( itemsData.get(position).getStatus());
        holder.txtItemType.setText( itemsData.get(position).getType());
        holder.txtItemHouse.setText( itemsData.get(position).getHouse());
    }
    //holder.imgAmenities.setImageBitmap();

    @Override
    public int getItemCount() {
        return itemsData.size();
    }

    class LostNfoundRowHolder extends RecyclerView.ViewHolder {
        TextView txtItemName;
        TextView txtItemType;
        TextView txtItemStatus;
        TextView txtItemHouse;
        ImageButton btn_delete;

        public LostNfoundRowHolder(@NonNull View itemView) {
            super(itemView);
            txtItemName = itemView.findViewById(R.id.txt_item_name);
            txtItemType = itemView.findViewById(R.id.txt_item_type);
            txtItemStatus = itemView.findViewById(R.id.txt_item_status);
            txtItemHouse= itemView.findViewById(R.id.txt_item_house);
            btn_delete = itemView.findViewById(R.id.btn_delete_a);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });
            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheComplaints);

        void onDelteClick(int positionOfTheComplaints);
    }




}