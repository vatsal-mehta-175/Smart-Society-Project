package com.example.smartsociety;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;

import java.util.ArrayList;

public class ComplaintsAdapter extends RecyclerView.Adapter<ComplaintsAdapter.ComplaintsRowHolder> {
  ArrayList<Complaints> complaintsData;
  Context context;
  MyClickInterface myClickInterface;



  public ComplaintsAdapter(ArrayList<Complaints> complaintsData, Context context, MyClickInterface myClickInterface) {
    this.context = context;
    this.complaintsData = complaintsData;
    this.myClickInterface = myClickInterface;
  }

  @NonNull
  @Override
  public ComplaintsRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(context).inflate(R.layout.complaints_row, parent, false);
    return new ComplaintsRowHolder(view);
  }

  @Override
  public void onBindViewHolder(@NonNull ComplaintsRowHolder holder, int position) {
    holder.txtComplaintName.setText(complaintsData.get(position).getName());
    holder.txtComplaintStatus.setText( complaintsData.get(position).getStatus());
  }
  //holder.imgAmenities.setImageBitmap();


  @Override
  public int getItemCount() {
    return complaintsData.size();
  }

  class ComplaintsRowHolder extends RecyclerView.ViewHolder {
    TextView txtComplaintName;
    TextView txtComplaintStatus;
    ImageButton btn_delete;

    public ComplaintsRowHolder(@NonNull View itemView) {
      super(itemView);
      txtComplaintName = itemView.findViewById(R.id.txt_complaints_name);
      txtComplaintStatus = itemView.findViewById(R.id.txt_complaints_status);
      btn_delete = itemView.findViewById(R.id.btn_delete_a);

      itemView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          myClickInterface.onItemClick(getAdapterPosition());
        }
      });
      btn_delete.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          myClickInterface.onDelteClick(getAdapterPosition());
        }
      });
    }
  }

  interface MyClickInterface {
    void onItemClick(int positionOfTheComplaints);

    void onDelteClick(int positionOfTheComplaints);
  }


}




