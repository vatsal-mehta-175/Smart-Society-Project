package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Visitor_MainActivity extends AppCompatActivity implements VisitorAdapter.MyClickInterface{


    RecyclerView recyclerView;
    String house_no;
    ImageView btnAdd;
    Context context=this;
    String type;
    VisitorAdapter.MyClickInterface obj=this;
    ArrayList<Visitor> Visitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor__main);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        recyclerView= findViewById(R.id.recycler_view);
        if(Visitor==null){Visitor=new ArrayList<>();}
        GETDATA();
        btnAdd=findViewById(R.id.imgbtn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, VisitorEntryActivity.class); //plus button
                startActivity(intent);
            }
        });


    }


    //three dots code starts
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.three_dots_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile:
                Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.logout:
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.changePass:
                Toast.makeText(this, "Change Password", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
//three dots code ends


    @Override
    public void onItemClick(int positionOfTheStaff) {
        Toast.makeText(this, "No Further details is available", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDelteClick(int postionOfTheComplaints) {
            visitorExit(Visitor.get(postionOfTheComplaints).getID());
           }

    void GETDATA() {
        String URL = "http://52.66.187.237:3000/visitor/0";//ask rahul
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(Visitor_MainActivity.this, "Empty list", Toast.LENGTH_LONG).show();
                } else {
                    Log.e("HELLO", response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        try {

                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            Visitor.add(new Visitor(jsonObject.getString("v_fname"), jsonObject.getString("v_lname"),jsonObject.getString("v_phone"),jsonObject.getString("r_house"),jsonObject.getString("e_time"),jsonObject.getString("ex_time"), jsonObject.getInt("v_id")));//creating object
                        } catch (JSONException e) {
                            System.out.println(e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }
                VisitorAdapter visitorAdapter = new VisitorAdapter(Visitor, context, obj);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                recyclerView.setAdapter(visitorAdapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(Visitor_MainActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();
                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void visitorExit(int id){
        String URL = "http://52.66.187.237:3000/visitor/" + id;
        StringRequest stringRequest = new StringRequest(Request.Method.PUT, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(Visitor_MainActivity.this, "Cannot Update", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(Visitor_MainActivity.this, "Visitor Exited", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Visitor_MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(Visitor_MainActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();

                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

}