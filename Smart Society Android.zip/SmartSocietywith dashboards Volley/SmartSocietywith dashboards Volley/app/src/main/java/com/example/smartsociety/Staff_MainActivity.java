package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Staff_MainActivity extends AppCompatActivity implements StaffAdapter.MyClickInterface {


    RecyclerView recyclerView;
    String house_no;
    ImageView btnAdd;
    Context context=this;
    String type;
    StaffAdapter.MyClickInterface obj=this;
    ArrayList<Staff> staff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff__main);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        recyclerView= findViewById(R.id.recycler_view);
        if(staff==null){staff=new ArrayList<>();}
        GETDATA();
        btnAdd=findViewById(R.id.imgbtn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, StaffRegistrationActivity.class); //plus button
                startActivity(intent);
            }
        });
        SharedPreferences sharedPreferences = getSharedPreferences("userinfo", Context.MODE_PRIVATE);
        type = sharedPreferences.getString("type", "defaultValue");
        house_no = sharedPreferences.getString("id", "defaultValue");
        if(!type.matches("admin")){
            btnAdd.animate().alpha(0).start();
            btnAdd.setEnabled(false);
        }

        
    }


    //three dots code starts
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.three_dots_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile:
                Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.logout:
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.changePass:
                Toast.makeText(this, "Change Password", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
//three dots code ends

    @Override
    public void onItemClick(int postionOfTheComplaints) {
        if(type.matches("admin"))
        {
            //Toast.makeText(this,"clicked "+amenities.get(postionOfTheAmenitie).getName(),Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(this,StaffUpdateActivity.class);
            intent.putExtra("id",staff.get(postionOfTheComplaints).getID());
            startActivity(intent);
        }
        else
        {
            Toast.makeText(this," No Further Details Available",Toast.LENGTH_SHORT).show();
        }

    }


    @Override
    public void onDelteClick(int postionOfTheComplaints) {

        if(type.matches("admin")){
            DELETEDATA(staff.get(postionOfTheComplaints).getID());
        }
        else
        {
            Toast.makeText(this," sorry, You can not delete",Toast.LENGTH_SHORT).show();
        }

    }

    void GETDATA() {
        String URL = "http://52.66.187.237:3000/staff";//ask rahul
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (jsonArray.length() == 0) {
                    Toast.makeText(Staff_MainActivity.this, "Empty list", Toast.LENGTH_LONG).show();
                } else {
                    Log.e("HELLO", response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        try {

                            JSONObject jsonObject = jsonArray.getJSONObject(i);

                            staff.add(new Staff(jsonObject.getString("s_fname"), jsonObject.getString("s_lname"),jsonObject.getString("s_phone"), jsonObject.getInt("s_id")));//creating object
                        } catch (JSONException e) {
                            System.out.println(e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }
                StaffAdapter staffAdapter = new StaffAdapter(staff, context, obj);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                recyclerView.setAdapter(staffAdapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(Staff_MainActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();
                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }
    void DELETEDATA(int id){
        String URL="http://52.66.187.237:3000/staff/"+id;//ask rahul
        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("HELLO", response);

                if (response.charAt(1) == '0') {
                    Toast.makeText(context, "Something went wrong", Toast.LENGTH_LONG).show();
                } else {
                    System.out.println(response);
                    Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Staff_MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("HELLO", "ERROR" + error.toString());
                Toast.makeText(context, "Something went wrong", Toast.LENGTH_LONG).show();
            }
        });

        MySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

}