package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StaffAdapter extends RecyclerView.Adapter<StaffAdapter.StaffRowHolder> {
    ArrayList<Staff> StaffData;
    Context context;
    StaffAdapter.MyClickInterface myClickInterface;



    public StaffAdapter(ArrayList<Staff> StaffData, Context context, StaffAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.StaffData = StaffData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public StaffAdapter.StaffRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.staff_row, parent, false);
        return new StaffAdapter.StaffRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StaffAdapter.StaffRowHolder holder, int position) {
        holder.txtStaffName.setText(StaffData.get(position).getFname()+" "+StaffData.get(position).getLname());
        holder.txtstaffphone.setText( StaffData.get(position).getPhone());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return StaffData.size();
    }

    class StaffRowHolder extends RecyclerView.ViewHolder {
        TextView txtStaffName;
        TextView txtstaffphone;
        ImageButton btn_delete;

        public StaffRowHolder(@NonNull View itemView) {
            super(itemView);
            txtStaffName = itemView.findViewById(R.id.txt_staff_name);
            txtstaffphone = itemView.findViewById(R.id.txt_staff_phone);
            btn_delete = itemView.findViewById(R.id.btn_delete_a);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });
            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheStaff);

        void onDelteClick(int positionOfTheStaff);
    }


}
