package com.example.smartsociety;

public class Visitor {
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRhouse() {
        return rhouse;
    }

    public void setRhouse(String rhouse) {
        this.rhouse = rhouse;
    }

    public String getEntry() {
        return entry;
    }

    public void setEntry(String entry) {
        this.entry = entry;
    }

    public String getExit() {
        return exit;
    }

    public void setExit(String exit) {
        this.exit = exit;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }





    private String fname;
    private String lname;
    private String phone;
    private String rhouse;
    private String entry;
    private String exit;

    private int ID;


    public Visitor(String fname,String lname,String phone,String rhouse,String entry,String exit,int ID){
        this.fname=fname;
        this.lname=lname;
        this.phone=phone;
        this.rhouse=rhouse;
        this.entry=entry;
        this.exit=exit;

        this.ID=ID;
    }

}
