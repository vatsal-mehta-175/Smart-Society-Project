package com.example.smartsociety;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

public class Complaints{
  private String name;
  private String image;
  private String des;
  private String comments;
  private String status;
  private int ID;



  private String house;
  public int getID() {
    return ID;
  }

  public void setID(int ID) {
    this.ID = ID;
  }



  public Complaints(String name,String image,String des,String comments,String status,int ID,String house){
    this.name=name;
    this.image=image;
    this.des=des;
    this.comments=comments;
    this.status=status;
    this.ID=ID;
    this.house=house;
  }
  public String getHouse() {
    return house;
  }

  public void setHouse(String house) {
    this.house = house;
  }
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }
  public String getDes() { return des; }

  public void setDes(String des) { this.des = des; }

  public String getStatus() { return status;}

  public void setStatus(String status) { this.status = status; }

}
