package com.example.smartsociety;

public class Tenants {

    private String fname;
    private String lname;
    private String phone;
    private String start_date;
    private String end_date;
    private int ID;
    private String house;


    public Tenants(String fname, String lname, String phone, String start_date, String end_date, int ID, String house){
        this.fname=fname;
        this.lname=lname;
        this.phone=phone;
        this.start_date=start_date;
        this.end_date=end_date;
        this.ID=ID;
        this.house=house;
    }


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }


}
