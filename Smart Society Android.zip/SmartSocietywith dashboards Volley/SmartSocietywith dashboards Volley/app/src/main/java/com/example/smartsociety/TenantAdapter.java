package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TenantAdapter extends RecyclerView.Adapter<TenantAdapter.TenantRowHolder> {

    ArrayList<Tenants> tenantsData;
    Context context;
    TenantAdapter.MyClickInterface myClickInterface;



    public TenantAdapter(ArrayList<Tenants> tenantsData, Context context, TenantAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.tenantsData = tenantsData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public TenantAdapter.TenantRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.tenant_row, parent, false);
        return new TenantAdapter.TenantRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TenantAdapter.TenantRowHolder holder, int position) {
        holder.txtTenantName.setText(tenantsData.get(position).getFname()+" "+tenantsData.get(position).getLname());
        holder.txtTenantHouse.setText( tenantsData.get(position).getHouse());
        holder.txtTenantPhone.setText( tenantsData.get(position).getPhone());
        holder.txtTenantStart.setText( tenantsData.get(position).getStart_date());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return tenantsData.size();
    }

    class TenantRowHolder extends RecyclerView.ViewHolder {
        TextView txtTenantName;
        TextView txtTenantHouse;
        TextView txtTenantPhone;
        TextView txtTenantStart;
        ImageButton btn_delete;

        public TenantRowHolder(@NonNull View itemView) {
            super(itemView);
            txtTenantName = itemView.findViewById(R.id.txt_tenant_name);
            txtTenantHouse = itemView.findViewById(R.id.txt_house);
            txtTenantPhone = itemView.findViewById(R.id.txt_tenant_phone);
            txtTenantStart = itemView.findViewById(R.id.txt_start_date);
            btn_delete = itemView.findViewById(R.id.btn_delete_a);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });
            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheComplaints);
        void onDelteClick(int positionOfTheComplaints);
    }


}
