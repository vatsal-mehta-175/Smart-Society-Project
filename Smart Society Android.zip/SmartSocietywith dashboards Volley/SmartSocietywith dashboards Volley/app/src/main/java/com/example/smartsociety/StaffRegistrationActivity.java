package com.example.smartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class StaffRegistrationActivity extends AppCompatActivity {

  EditText fname, lname, phone;
  Button addbtn;
  Context context = this;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_staff_registration);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    fname =findViewById(R.id.staff_fname);
    lname =findViewById(R.id.staff_lname);
    phone =findViewById(R.id.staff_phone);
    addbtn=findViewById(R.id.btn_add);




  }

  //three dots code starts
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.three_dots_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.profile:
        Toast.makeText(this, "SHOW PROFILE", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.logout:
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        return true;
      case R.id.changePass:
        startActivity(new Intent(getApplicationContext(), ChangePasswordActivity.class));
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }

  }
  //three dots code ends
  public void StaffRegister(View view) {


    if (fname.getText().toString().matches("") || lname.getText().toString().matches("") || phone.getText().toString().matches("")) {
      Toast.makeText(this, "Please Fill all the values", Toast.LENGTH_SHORT).show();
    } else {
      if (phone.getText().toString().length() != 10) {
        Toast.makeText(this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
      } else {


        String URL = "http://52.66.187.237:3000/staff";
        Log.e("HELLO", "URL = " + URL);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
          @Override
          public void onResponse(String response) {
            Log.e("HELLO", response);

            Toast.makeText(StaffRegistrationActivity.this, "Staff Successfully Added", Toast.LENGTH_LONG).show();


            Intent intent;
            intent = new Intent(getApplicationContext(), Staff_MainActivity.class);

            startActivity(intent);
            finish();



          }
        }, new Response.ErrorListener() {
          @Override
          public void onErrorResponse(VolleyError error) {
            Log.e("HELLO", "ERROR" + error.toString());
            Toast.makeText(StaffRegistrationActivity.this, "All Fields Required", Toast.LENGTH_LONG).show();
          }
        }) {
          @Override
          protected Map<String, String> getParams() throws AuthFailureError {

            Map<String, String> params = new HashMap<>();

            params.put("s_fname", fname.getText().toString());
            params.put("s_lname", lname.getText().toString());
            params.put("s_phone", phone.getText().toString());

            return params;
          }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);

      }


    }

  }
}
