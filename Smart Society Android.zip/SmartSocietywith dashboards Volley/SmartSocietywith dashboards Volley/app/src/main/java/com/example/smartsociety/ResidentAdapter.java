package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ResidentAdapter  extends RecyclerView.Adapter<ResidentAdapter.ResidentRowHolder> {
    ArrayList<Resident> ResidentData;
    Context context;
    ResidentAdapter.MyClickInterface myClickInterface;



    public ResidentAdapter(ArrayList<Resident> ResidentData, Context context, ResidentAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.ResidentData = ResidentData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public ResidentAdapter.ResidentRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.resident_row, parent, false);
        return new ResidentAdapter.ResidentRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResidentAdapter.ResidentRowHolder holder, int position) {
        holder.txt_res_name.setText(ResidentData.get(position).getFirst()+" "+ResidentData.get(position).getLast());
        holder.txt_res_house.setText( ResidentData.get(position).getRhouse());
        holder.txt_res_phone.setText( ResidentData.get(position).getPhone());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return ResidentData.size();
    }

    class ResidentRowHolder extends RecyclerView.ViewHolder {
        TextView txt_res_house;
        TextView txt_res_name;
        TextView txt_res_phone;
        Button btn_delete;
        Button btn_accept;

        public ResidentRowHolder(@NonNull View itemView) {
            super(itemView);
            txt_res_house = itemView.findViewById(R.id.txt_res_house);
            txt_res_name = itemView.findViewById(R.id.txt_res_name);
            txt_res_phone = itemView.findViewById(R.id.txt_res_phone);
            btn_accept = itemView.findViewById(R.id.txt_accept);
            btn_delete = itemView.findViewById(R.id.txt_decline);

            btn_accept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });
            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onDelteClick(getAdapterPosition());
                }
            });
        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheStaff);

        void onDelteClick(int positionOfTheStaff);
    }

}
