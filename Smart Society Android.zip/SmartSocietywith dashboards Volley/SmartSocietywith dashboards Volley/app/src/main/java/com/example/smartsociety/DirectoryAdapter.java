package com.example.smartsociety;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DirectoryAdapter extends RecyclerView.Adapter<DirectoryAdapter.DirectoryRowHolder> {

    ArrayList<Resident> DirectoryData;
    Context context;
    DirectoryAdapter.MyClickInterface myClickInterface;



    public DirectoryAdapter(ArrayList<Resident> DirectoryData, Context context, DirectoryAdapter.MyClickInterface myClickInterface) {
        this.context = context;
        this.DirectoryData = DirectoryData;
        this.myClickInterface = myClickInterface;
    }

    @NonNull
    @Override
    public DirectoryAdapter.DirectoryRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.directory_row, parent, false);
        return new DirectoryAdapter.DirectoryRowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DirectoryAdapter.DirectoryRowHolder holder, int position) {
        holder.txtName.setText(DirectoryData.get(position).getFirst()+" "+DirectoryData.get(position).getLast());
        holder.txtphone.setText( DirectoryData.get(position).getPhone());
        holder.txthouse.setText( DirectoryData.get(position).getRhouse());
    }
    //holder.imgAmenities.setImageBitmap();


    @Override
    public int getItemCount() {
        return DirectoryData.size();
    }

    class DirectoryRowHolder extends RecyclerView.ViewHolder {
        TextView txtName;
        TextView txtphone;
        TextView txthouse;

        public DirectoryRowHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txt_res_name);
            txtphone = itemView.findViewById(R.id.txt_res_phone);
            txthouse = itemView.findViewById(R.id.txt_res_house);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickInterface.onItemClick(getAdapterPosition());
                }
            });

        }
    }

    interface MyClickInterface {
        void onItemClick(int positionOfTheStaff);

    }

}
