package com.example.smartsociety;

public class LostNFound {

    private String name;
    private String image;
    private String des;
    private String type;
    private String status;
    private int ID;
    private String house;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }



    public LostNFound(String name,String image,String des,String type,String status,int ID,String house){
        this.name=name;
        this.image=image;
        this.des=des;
        this.type=type;
        this.status=status;
        this.ID=ID;
        this.house=house;
    }
    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public String getDes() { return des; }

    public void setDes(String des) { this.des = des; }

    public String getStatus() { return status;}

    public void setStatus(String status) { this.status = status; }

}
