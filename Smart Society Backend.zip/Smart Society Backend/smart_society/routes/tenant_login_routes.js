var tenant=require('../models/login_model')
var express=require('express');
var router=express.Router();
const bcrypt = require('bcrypt');
router.post('/',function(req,res,next){
    tenant.tenantLogin(req.body,async function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            
                if(rows.length===0)
                res.json("0");
                else{
                const match = await bcrypt.compare(req.body.password,rows[0].t_password);
                if(match)
                res.json({id:rows[0].t_id,type:"tenant"});
                else
                res.json("0");
                }
        }
    });
});

router.put('/',function(req,res,next){
    tenant.tenantChangePassword(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;
