var complaints=require('../models/complaints_model')
var express=require('express');
var router=express.Router();


router.get('/button_id/:button_id',function(req,res,next){

    if(req.params.button_id==="1")
    {
      complaints.getAllActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      complaints.getAllNotActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.get('/:Complaint_id?',function(req,res,next){

    if(req.params.Complaint_id)
    {
        complaints.getComplaintById(req.params.Complaint_id,function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
        complaints.getAllActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });



router.put('/:Complaint_id',function(req,res,next){
    complaints.UpdateComplaintById(req.params.Complaint_id,req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})
router.delete('/:Complaint_id',function(req,res,next){
  
    complaints.DeleteComplaint(req.params.Complaint_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {   //console.log(JSON.stringify(rows));
            res.json(rows);
        }
    });
});



module.exports=router;