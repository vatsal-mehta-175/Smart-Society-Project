var resident=require('../models/resident_model')
var express=require('express');
var router=express.Router();

router.get('/button_id/:button_id',function(req,res,next){
    if(req.params.button_id==="1")
    {
      resident.getAllApproveResident(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      resident.getAllNotApproveResident(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

  router.get('/get_house_numbers',function(req,res,next){
      resident.getHouseNumbers(function(err, rows) {
          if (err) {
            res.json(err);
          } else {
            res.json(rows);
          }
      });
  });
  
router.get('/:resident_id?',function(req,res,next){
        if(req.params.resident_id)
        {
            resident.getResidentById(req.params.resident_id,function(err, rows) {
            if (err) {
              res.json(err);
            } else {
              res.json(rows);
            }
          });
        }
        else
        {
            resident.getAllApproveResident(function(err, rows) {
            if (err) {
              res.json(err);
            } else {
              res.json(rows);
            }
          });
        }
      
});




router.post('/',function(req,res,next){

    resident.residenceRegister(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        { 
            res.json(rows);
        }
    });
});

router.put('/:resident_id',function(req,res,next){
   
    resident.updateResident(req.params.resident_id,req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})

router.put('/approve/:resident_id',function(req,res,next){
   
    resident.approveResident(req.params.resident_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})

router.delete('/:resident_id',function(req,res,next){

        resident.deleteResident(req.params.resident_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {  
            res.json(rows);
        }
    });
});


module.exports=router;
