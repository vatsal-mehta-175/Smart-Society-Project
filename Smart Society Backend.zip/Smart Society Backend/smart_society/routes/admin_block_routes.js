var bl = require('../models/block_model');
var express = require('express');
var router = express.Router();

router.get('/:block_no?', function (req, res, next) {

  if (req.params.block_no) {
    bl.getNoticeByNoticeId(req.params.block_no, function (err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else {
    bl.getAllBlock(function (err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});

router.post('/', function (req, res, next) {


  bl.addBlock(req.body, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});

router.put('/:block_no', function (req, res, next) {
  bl.updateBlockById(req.params.block_no, req.body, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});

router.delete('/:block_no', function (req, res, next) {
  bl.deleteBlock(req.params.block_no, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});
module.exports = router;
