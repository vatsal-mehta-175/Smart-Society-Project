var amenities=require('../models/amenities_model')
var express=require('express');
var router=express.Router();
var fs = require("fs");

router.post('/',function(req,res,next){

  var bitmap = new Buffer(req.body.uploaded_image, 'base64');
console.log(bitmap);
  var file_name=new Date().getTime()+".jpeg";
  fs.writeFileSync("public/amenities/"+file_name, bitmap);
  req.body.path="/"+file_name;
  console.log("true");
    amenities.AddAmenities(req.body,function(err,rows){
        if(err)
        {
          console.log(err);
            res.json(err);
        }
        else
        {  
           // console.log(JSON.stringify(rows));
            res.json(rows);

        }
    });
});

router.get('/:Amenities_id?',function(req,res,next){

    if(req.params.Amenities_id)
    {
      amenities.getAmenitiesById(req.params.Amenities_id,function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      amenities.getAllAmenities(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.delete('/:amenities_id',function(req,res,next){
    console.log(req.body);
    amenities.DeleteAmenities(req.params.amenities_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {   //console.log(JSON.stringify(rows));
            res.json(rows);
        }
    });
});

router.put('/:amenities_id',function(req,res,next){
    amenities.UpdateAmenitiesById(req.params.amenities_id,req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;