var complaints=require('../models/complaints_model')
var express=require('express');
var router=express.Router();
var fs = require("fs");

router.post('/',function(req,res,next){
  
if(req.body.uploaded_image)
  {
  var bitmap = new Buffer(req.body.uploaded_image, 'base64');
//console.log(bitmap);
  var file_name=new Date().getTime()+".jpeg";
  fs.writeFileSync("public/complaints/"+file_name, bitmap);
  req.body.path="/"+file_name;

}
  //console.log("true");
  complaints.AddComplaint(req.body,function(err,rows){
        if(err)
        {
          console.log(err);
            res.json(err);
        }
        else
        {  
           // console.log(JSON.stringify(rows));
            res.json(rows);

        }
    });
});

router.get('/button_id/:button_id',function(req,res,next){

    if(req.params.button_id==="1")
    {
      complaints.getAllActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      complaints.getAllNotActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.get('/:Complaint_id?',function(req,res,next){

    if(req.params.Complaint_id)
    {
        complaints.getComplaintById(req.params.Complaint_id,function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
        complaints.getAllActiveComplaint(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.delete('/:Complaint_id',function(req,res,next){
  
    complaints.DeleteComplaint(req.params.Complaint_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {   //console.log(JSON.stringify(rows));
            res.json(rows);
        }
    });
});


module.exports=router;