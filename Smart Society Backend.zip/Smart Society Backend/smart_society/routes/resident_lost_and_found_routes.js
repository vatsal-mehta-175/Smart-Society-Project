var lost_found=require('../models/lost_and_found_model')
var express=require('express');
var router=express.Router();
var fs = require("fs");

router.post('/',function(req,res,next){
  
if(req.body.uploaded_image)
  {
  var bitmap = new Buffer(req.body.uploaded_image, 'base64');
//console.log(bitmap);
  var file_name=new Date().getTime()+".jpeg";
  fs.writeFileSync("public/lost_and_found/"+file_name, bitmap);
  req.body.path="/"+file_name;

}
  //console.log("true");
  lost_found.AddLostFound(req.body,function(err,rows){
        if(err)
        {
          console.log(err);
            res.json(err);
        }
        else
        {  
           // console.log(JSON.stringify(rows));
            res.json(rows);

        }
    });
});

router.get('/button_id/:button_id',function(req,res,next){

    if(req.params.button_id==="1")
    {
      lost_found.getAllActiveLostFound(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      lost_found.getAllNotActiveLostFound(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.get('/:LostFound_id?',function(req,res,next){

    if(req.params.LostFound_id)
    {
        lost_found.getLostFoundById(req.params.LostFound_id,function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
        lost_found.getAllActiveLostFound(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.delete('/:LostFound_id',function(req,res,next){
  
    lost_found.DeleteLostFound(req.params.LostFound_id,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {   //console.log(JSON.stringify(rows));
            res.json(rows);
        }
    });
});

router.put('/:LostFound_id',function(req,res,next){
    lost_found.UpdateLostFoundById(req.params.LostFound_id,req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;