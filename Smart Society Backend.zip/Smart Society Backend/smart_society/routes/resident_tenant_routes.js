var tn=require('../models/tenant_model');
var express = require('express');
var router = express.Router();



router.get('/:t_id?',function(req,res,next){

  if(req.params.g_id)
  {
    tn.getTnByTnId(req.params.t_id,function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else
  {
    tn.getAllTn(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});



  router.post('/',function(req,res,next){
    
    tn.addTn(req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.put('/:t_id',function(req,res,next){
    tn.updateTnByTnId(req.params.t_id,req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.delete('/:t_id',function(req,res,next){
    tn.deleteTenant(req.params.t_id,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

module.exports=router;
