var r_amenities=require('../models/amenities_model');
var express = require('express');
var router = express.Router();

router.get('/:Amenities_id?',function(req,res,next){

  if(req.params.Amenities_id)
  {
    r_amenities.getAmenitiesById(req.params.Amenities_id,function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else
  {
    r_amenities.getAllAmenities(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});

module.exports=router;
