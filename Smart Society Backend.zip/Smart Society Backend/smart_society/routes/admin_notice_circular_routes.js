var n_c = require('../models/notice_circular_model');
var express = require('express');
var router = express.Router();
var fs = require('fs');

router.get('/:notice_id?', function (req, res, next) {

  if (req.params.notice_id) {
    n_c.getNoticeByNoticeId(req.params.notice_id, function (err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else {
    n_c.getAllNotice(function (err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});

router.post('/', function (req, res, next) {

  /*var bitmap = new Buffer(req.body.uploaded_image, 'base64');
  
  var file_name=new Date().getTime()+".pdf";
  fs.writeFileSync("public/notice_circular/"+file_name, bitmap);*/
  if (!req.files)
    return res.json('No files were uploaded.');
  //upload image field name in form "upload_image" in post request
  var file = req.files.uploaded_image;
  //rahul.jpeg ... rahul [0] , jpeg[1]
  var file_name = new Date().getTime() + "." + file.name.substr((file.name.lastIndexOf('.') + 1));

  if (file.mimetype == "text/plain" || file.mimetype == "application/pdf" || file.mimetype == "image/jpeg" || file.mimetype == "image/png" || file.mimetype == "image/gif") {

    file.mv('public/notice_circular/' + file_name, function (err) {

      if (err)
        return res.json(err);
    });
  } else {
    message = "This format is not allowed , please upload file with '.png','.gif','.jpg','.pdf'";
    return res.json(message);
  }


  req.body.path = "/" + file_name;



  n_c.addNotice(req.body, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});

router.put('/:notice_id', function (req, res, next) {
  n_c.updateNoticeByNoticeId(req.params.notice_id, req.body, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});

router.delete('/:notice_id', function (req, res, next) {
  n_c.deleteNotice(req.params.notice_id, function (err, rows) {
    if (err) {
      res.json(err);
    }
    else {
      res.json(rows);
    }
  });
});
module.exports = router;
