var gc=require('../models/gatekeeper_model');
var express = require('express');
var router = express.Router();

router.get('/button_id/:button_id',function(req,res,next){

    if(req.params.button_id==="1")
    {
      gc.getAllActiveGc(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      gc.getAllNotActiveGc(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.get('/:g_id?',function(req,res,next){

  if(req.params.g_id)
  {
    gc.getGcByGcId(req.params.g_id,function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else
  {
    gc.getAllActiveGc(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});



  router.post('/',function(req,res,next){
    
    gc.addGc(req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.put('/:g_id',function(req,res,next){
    gc.updateGcByGcId(req.params.g_id,req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.delete('/:g_id',function(req,res,next){
    gc.deleteGC(req.params.g_id,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });
module.exports=router;
