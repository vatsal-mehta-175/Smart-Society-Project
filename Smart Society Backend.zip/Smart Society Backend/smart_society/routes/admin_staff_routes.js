var staff=require('../models/staff_model');
var express = require('express');
var router = express.Router();

router.get('/button_id/:button_id',function(req,res,next){

    if(req.params.button_id==="1")
    {
      staff.getAllActiveStaff(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
      staff.getAllNotActiveStaff(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

router.get('/:staff_id?',function(req,res,next){

  if(req.params.staff_id)
  {
    staff.getStaffByStaffId(req.params.staff_id,function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else
  {
    staff.getAllActiveStaff(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});



  router.post('/',function(req,res,next){
    
    staff.addStaff(req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.put('/:staff_id',function(req,res,next){
    staff.updateStaffByStaffId(req.params.staff_id,req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

module.exports=router;
