var residence=require('../models/login_model')
var express=require('express');
const { compile } = require('jade');
var router=express.Router();
const bcrypt = require('bcrypt');
router.post('/',function(req,res,next){
    residence.residenceLogin(req.body,async function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            if(rows.length===0)
                res.json("0");
            
            else{
            const match = await bcrypt.compare(req.body.password,rows[0].r_password);
            if(match){

                if(JSON.stringify(rows[0].approve_flag)==="1")
                res.json({id:rows[0].r_house,type:"resident"});
                else
                res.json("2");
            }
           
            else
            res.json("0");
            }
        }
    });
});

router.put('/',function(req,res,next){
    residence.residenceChangePassword(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;
