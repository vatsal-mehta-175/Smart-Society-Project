var admin=require('../models/login_model')
var express=require('express');
var router=express.Router();
const bcrypt = require('bcrypt');
router.post('/',function(req,res,next){

    admin.adminLogin(req.body,async function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {       
                if(rows.length===0)
                res.json("0");
                else{
                const match = await bcrypt.compare(req.body.password,rows[0].a_password);
                if(match)
                res.json({id:rows[0].a_id,type:"admin"});
                else
                res.json("0");
                }
        }
    });
});

router.put('/',function(req,res,next){
    admin.adminChangePassword(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;
