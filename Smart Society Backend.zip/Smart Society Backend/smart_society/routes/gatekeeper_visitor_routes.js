var visitor=require('../models/visitor_model');
var express = require('express');
var router = express.Router();

router.get('/',function(req,res,next){
  visitor.getHouseNumber(function(err,rows){
    if(err)
    {
    res.json(err);
    }
    else{
    res.json(rows);
    }
   });

});

router.get('/:button_id',function(req,res,next){

    if(req.params.button_id==="0")
    {
        visitor.getAllInVisitor(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
    else
    {
        visitor.getAllOutVisitor(function(err, rows) {
        if (err) {
          res.json(err);
        } else {
          res.json(rows);
        }
      });
    }
  
  });

  router.post('/',function(req,res,next){
    req.body.time=new Date().getTime();
    visitor.addVisitor(req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  router.put('/:visitor_id',function(req,res,next){
    req.body.time=new Date().getTime();
    visitor.exitVisitor(req.params.visitor_id,req.body,function(err,rows){
     if(err)
     {
     res.json(err);
     }
     else{
     res.json(rows);
     }
    });
  });

  
module.exports=router;
