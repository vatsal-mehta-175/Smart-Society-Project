var staff_log=require('../models/staff_log_model')
var express=require('express');
var router=express.Router();

router.get('/button_id/:button_id',function(req,res,next){

  if(req.params.button_id==="1")
  {
    staff_log.getAllActiveStaffLog(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }
  else
  {
    staff_log.getAllNotActiveStaffLog(function(err, rows) {
      if (err) {
        res.json(err);
      } else {
        res.json(rows);
      }
    });
  }

});

router.get('/:staff_log_id?',function(req,res,next){

        if(req.params.staff_log_id)
        {
            staff_log.getStaffLogById(req.params.staff_log_id,function(err, rows) {
            if (err) {
              res.json(err);
            } else {
              res.json(rows);
            }
          });
        }
        else
        {
            staff_log.getAllActiveStaffLog(function(err, rows) {
            if (err) {
              res.json(err);
            } else {
              res.json(rows);
            }
          });
        }
      
});


router.post('/',function(req,res,next){

    req.body.time=new Date().getTime();
    staff_log.addStaffEntry(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        { 
            res.json(rows);
        }
    });
});

router.put('/:staff_log_id',function(req,res,next){
    req.body.time=new Date().getTime();
    staff_log.addStaffExit(req.params.staff_log_id,req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;
