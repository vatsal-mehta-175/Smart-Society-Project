var gate=require('../models/login_model')
var express=require('express');
var router=express.Router();
const bcrypt = require('bcrypt');
router.post('/',function(req,res,next){
    gate.gateKeeperLogin(req.body,async function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            if(rows.length===0)
                res.json("0");
            else{
            const match = await bcrypt.compare(req.body.password,rows[0].g_password);
            if(match)
            {
          
            if(rows[0].g_active_flag===1)
                res.json({id:rows[0].g_id,type:"gatekeeper"});
            else
                res.json("0");
            }
            else
            res.json("0");
            }
        }
    });
});

router.put('/',function(req,res,next){
    gate.gateKeeperChangePassword(req.body,function(err,rows){
        if(err)
        {
            res.json(err);
        }
        else
        {
            res.json(rows);
        }
    })
})


module.exports=router;
