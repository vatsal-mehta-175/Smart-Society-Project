var db=require('../dbconnection');
var staff={
    getStaffByStaffId:function(Staff_id,callback)
    {
        return db.query("select * from staff where s_id=?",[Staff_id],callback);
    },
    getAllActiveStaff:function(callback)
    {
        return db.query("select * from staff where active_flag=1",callback);
    },
    getAllNotActiveStaff:function(callback)
    {
        return db.query("select * from staff where active_flag=0",callback);
    },
    addStaff:function(item,callback)
    {
       // var date=new Date(item.date);
        return db.query("insert into staff (s_fname,s_lname,s_phone)  values(?,?,?)",[item.s_fname,item.s_lname,item.s_phone],callback);
    },
    updateStaffByStaffId:function(Staff_id,item,callback){
       // var date=new Date(item.date);
        return db.query("update staff set s_fname=?,s_lname=?,s_phone=?,active_flag=? where s_id=?",[item.s_fname,item.s_lanme,item.s_phone,item.flag,Staff_id],callback);
    },

};
module.exports=staff;
