var db=require('../dbconnection');
const bcrypt = require('bcrypt');
var resident={

    async residenceRegister(item,callback)
    {
        const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("insert into resident (r_house,r_fname,r_lname,r_phone,r_password)  values(?,?,?,?,?)",[item.id,item.fname,item.lname,item.phone,hashedPassword],callback);
    },

    getResidentById(Resident_id,callback)
    {
        return db.query("select * from resident where r_house=? ",[Resident_id],callback);
    },

    getAllApproveResident(callback)
    {
        return db.query("select * from resident where approve_flag=1",callback);
    },
    getAllNotApproveResident(callback)
    {
        return db.query("select * from resident where approve_flag=0",callback);
    },

    getHouseNumbers(callback){
        return db.query("select * from block",callback);
    },
    approveResident(Resident_id,callback)
    {
        return db.query("update resident set approve_flag=1 where r_house=?",[Resident_id],callback);
    },

    updateResident(Resident_id,item,callback){
        return db.query("update resident set r_fname=?,r_lname=?,r_phone=? where r_house=?",[item.fname,item.lname,item.phone,Resident_id],callback);
    },

    deleteResident(Resident_id,callback){
        return db.query("delete from resident where r_house=?",[Resident_id],callback);
    }
}

module.exports=resident;
