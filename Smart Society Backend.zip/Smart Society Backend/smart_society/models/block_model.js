var db=require('../dbconnection');
var block={
    getBlockByBlockId:function(block_no,callback)
    {
        return db.query("select * from block where b_block_no=?",[block_no],callback);
    },
    getAllBlock:function(callback)
    {
        return db.query("select * from block",callback);
    },
    addBlock:function(item,callback)
    {
        return db.query("insert into block (b_block_no)  values(?)",[item.block_no],callback);
    },
    updateBlockById:function(block_no,item,callback){
        return db.query("update block set b_block_no=? where b_block_no=?",[item.block_no,block_no],callback);
    },

    deleteBlock:function(block_no,callback)
    {
        return db.query("delete from block where b_block_no=?",[block_no],callback);
    },


};
module.exports=block;
