var db=require('../dbconnection');
const bcrypt = require('bcrypt');

var gc={
    getGcByGcId:function(gc_id,callback)
    {
        return db.query("select * from gate_keeper where g_id=?",[gc_id],callback);
    },
    getAllActiveGc:function(callback)
    {
        return db.query("select * from gate_keeper where g_active_flag=1",callback);
    },
    getAllNotActiveGc:function(callback)
    {
        return db.query("select * from gate_keeper where g_active_flag=0",callback);
    },
    addGc:async function(item,callback)
    {
       
       const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("insert into gate_keeper (g_fname,g_lname,g_password,g_email,g_phone,g_s_time,g_e_time)  values(?,?,?,?,?,?,?)",[item.g_name,item.g_lname,hashedPassword,item.g_email,item.g_phone,item.start_time,item.exit_time],callback);
    },
    updateGcByGcId:function(g_id,item,callback){
        return db.query("update gate_keeper set g_fname=?,g_lname=?,g_email=?,g_phone=?,g_s_time=?,g_e_time=?,g_active_flag=? where g_id=?",[item.g_name,item.g_lname,item.g_email,item.g_phone,item.start_time,item.exit_time,item.g_flag,g_id],callback);
    },
    deleteeGC:function(g_id,callback){
        return db.query("delete from gate_keeper where g_id=?",[g_id],callback);
    }

};
module.exports=gc;


/*
{
        "g_name": "Vatsal",
        "g_lname": "Mehta",
        "g_password": "gatekeeper2",
        "g_email": "gatekeeper2@gmail.com",
        "g_phone": "9998348875",
        "start_time": "13:00:00",
        "exit_time": "21:00:00",
        "g_flag":"0"
}
*/