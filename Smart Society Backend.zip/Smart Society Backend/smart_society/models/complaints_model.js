var db=require('../dbconnection');


var complaints={
    getComplaintById:function(Complaint_id,callback)
    {
        return db.query("select * from complaints where c_id=?",[Complaint_id],callback);
    },
    getAllActiveComplaint:function(callback)
    {
        return db.query("select * from complaints where c_status=0",callback);
    },
    getAllNotActiveComplaint:function(callback)
    {
        return db.query("select * from complaints where c_status=1",callback);
    },
    AddComplaint:function(item,callback)
    {
        return db.query("INSERT INTO complaints (c_name,c_description,c_file_path,r_house) VALUES (?,?,?,?)",[item.c_title,item.c_description,item.path,item.r_house],callback);
    },
    UpdateComplaintById:function(Complaint_id,item,callback){

        return db.query("UPDATE complaints set c_comments=?,c_status=?,a_id=? where c_id=?",[item.c_comments,item.c_status,item.a_id,Complaint_id],callback);
    },
    DeleteComplaint:function(Complaint_id,callback){

        return db.query("delete from complaints where c_id=?",[Complaint_id],callback);
     }

};

module.exports=complaints;
