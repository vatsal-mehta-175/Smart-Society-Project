var db=require('../dbconnection');
const bcrypt = require('bcrypt');

var login={
    adminLogin(item,callback)
    {
        return db.query("select * from admin where a_id=?",[item.id],callback);
    },
    async adminChangePassword(item,callback)
    {
        const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("update admin set a_password=? where a_id=?",[hashedPassword,item.id],callback);
    },

    residenceLogin(item,callback)
    {
        return db.query("select * from resident where r_house=?",[item.id],callback);
    },
    async residenceChangePassword(item,callback)
    {
        const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("update resident set r_password=? where r_house=?",[hashedPassword,item.id],callback);
    },

    gateKeeperLogin(item,callback)
    {
        return db.query("select * from gate_keeper where g_email=?",[item.id],callback);
    },
    async gateKeeperChangePassword(item,callback)
    {
        const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("update gate_keeper set g_password=? where g_email=?",[hashedPassword,item.id],callback);
    },

    tenantLogin(item,callback)
    {
        return db.query("select * from tenant where t_email=?",[item.id],callback);
    },
    async tenantChangePassword(item,callback)
    {
        const hashedPassword = await bcrypt.hash(item.password, 10);
        return db.query("update tenant set t_password=? where t_email=?",[hashedPassword,item.id],callback);
    }

}

module.exports=login;
