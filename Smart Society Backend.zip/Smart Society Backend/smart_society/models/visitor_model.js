var db=require('../dbconnection');
var visitor={
    
    getHouseNumber:function(callback){
        return db.query("select r_house from resident order by r_house",callback);
    },
    getAllInVisitor:function(callback)
    {
        return db.query("select * from visitor join resident on visitor.r_house=resident.r_house where v_exit_time IS NULL order by v_entry_time",callback);
    },
    getAllOutVisitor:function(callback)
    {
        return db.query("select * from visitor join resident on visitor.r_house=resident.r_house where v_exit_time IS NOT NULL order by v_exit_time desc",callback);
    },
    addVisitor:function(item,callback)
    {
       // var date=new Date(item.date);
        return db.query("insert into visitor (v_fname,v_lname,v_phone,r_house,g_id,v_entry_time,v_count)  values(?,?,?,?,?,?,?)",[item.v_fname,item.v_lname,item.phone,item.house,item.g_id,item.time,item.count],callback);
    },
    exitVisitor:function(visitor_id,item,callback)
    {
       // var date=new Date(item.date);
        return db.query("update visitor set v_exit_time=? WHERE v_id=?",[item.time,visitor_id],callback);
    },

    // deleteNotice:function(v_id,callback)
    // {
    //     return db.query("delete from visitor where v_id=?",[v_id],callback);
    // }


};
module.exports=visitor;