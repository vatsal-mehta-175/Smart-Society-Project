var db=require('../dbconnection');
var staff_log={

    getAllActiveStaffLog:function(callback)
    {
        return db.query("select * from staff_log join staff on staff.s_id=staff_log.s_id where s_exit_time is null order by s_entry_time",callback);
    },
    getAllNotActiveStaffLog:function(callback)
    {
        return db.query("select * from staff_log join staff on staff.s_id=staff_log.s_id where s_exit_time is not null order by s_exit_time desc",callback);
    },
    getStaffLogById:function(Staff_Log_id,callback){
        
        return db.query("select * from staff_log join staff on staff.s_id=staff_log.s_id where staff_log.s_id=? order by s_entry_time desc",[Staff_Log_id],callback);
    },
    addStaffEntry:function(item,callback)
    {
        return db.query("insert into staff_log (s_id,s_entry_time,g_id)  values(?,?,?)",[item.s_id,item.time,item.g_id],callback);
    },
    addStaffExit:function(Staff_Log_id,item,callback){
        return db.query("update staff_log set s_exit_time=? where sl_id=?",[item.time,Staff_Log_id],callback);
    },

    
};
module.exports=staff_log;
