var db=require('../dbconnection');


var amenities={
    getAmenitiesById:function(Amenities_id,callback)
    {
        return db.query("select * from amenities where am_id=?",[Amenities_id],callback);
    },
    getAllAmenities:function(callback)
    {
        return db.query("select * from amenities",callback);
    },
    AddAmenities:function(item,callback)
    {
        return db.query("INSERT INTO amenities (am_name,am_description,am_status,am_image_path) VALUES (?,?,?,?)",[item.am_name,item.am_description,item.am_status,item.path],callback);
    },
    UpdateAmenitiesById:function(Amenities_id,item,callback){

        return db.query("UPDATE amenities set am_name=?, am_description=?, am_status=? where am_id=?",[item.am_name,item.am_description,item.am_status,Amenities_id],callback);
    },
    DeleteAmenities:function(Amenities_id,callback){

        return db.query("delete from amenities where am_id=?",[Amenities_id],callback);
     }



};

module.exports=amenities;
