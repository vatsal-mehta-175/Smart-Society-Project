var db=require('../dbconnection');
var tn={
    getTnByTnId:function(tn_id,callback)
    {
        return db.query("select * from tenant where t_id=?",[tn_id],callback);
    },
    getAllTn:function(callback)
    {
        return db.query("select * from tenant",callback);
    },
    addTn:function(item,callback)
    {
        return db.query("insert into tenant (t_fname,t_lname,t_phone,t_password,t_email,start_date,end_date)  values(?,?,?,?,?,?,?,?)",[item.t_name,item.t_lname,item.t_phone,item.t_password,item.t_email,item.start_date,item.end_date],callback);
    },
    updateTnByTnId:function(g_id,item,callback){
        return db.query("update tenant set t_fname=?,t_lname=?,t_phone=?,t_password=?,t_email=?,start_date=?,end_date=? where t_id=?",[item.t_name,item.g_lname,item.t_phone,item.t_password,item.t_email,item.start_date,item.end_date,g_id],callback);
    },

};
module.exports=tn;
