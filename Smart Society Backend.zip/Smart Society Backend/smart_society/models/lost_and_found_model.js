var db=require('../dbconnection');


var lost_and_found={
    getLostFoundById:function(LostFound_id,callback)
    {
        return db.query("select * from lost_and_found where i_id=?",[LostFound_id],callback);
    },
    getAllActiveLostFound:function(callback)
    {
        return db.query("select * from lost_and_found where i_status=0",callback);
    },
    getAllNotActiveLostFound:function(callback)
    {
        return db.query("select * from lost_and_found where i_status=1",callback);
    },
    AddLostFound:function(item,callback)
    {
        return db.query("INSERT INTO lost_and_found (i_name,i_description,i_file_path,i_type,r_house) VALUES (?,?,?,?,?)",[item.i_name,item.i_description,item.path,item.i_type,item.r_house],callback);
    },
    UpdateLostFoundById:function(LostFound_id,item,callback){

        return db.query("UPDATE lost_and_found set i_status=? where i_id=?",[item.status,LostFound_id],callback);
    },
    DeleteLostFound:function(LostFound_id,callback){

        return db.query("delete from lost_and_found where i_id=?",[LostFound_id],callback);
     }

};

module.exports=lost_and_found;
